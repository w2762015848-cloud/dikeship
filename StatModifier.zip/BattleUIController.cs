using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Pool;
using UnityEngine.UI;

namespace BattleSystem
{
    public class BattleUIController : MonoBehaviour
    {
        [Header("���ܰ�ť")]
        public Button[] skillButtons;
        public TextMeshProUGUI[] skillButtonTexts;
        public Image[] skillButtonIcons;

        [Header("UI����")]
        public RectTransform damageCanvas;
        public GameObject damageTextPrefab;

        [Header("������ʾ")]
        public TextMeshProUGUI descriptionTooltipText;

        [Header("��ɫ����")]
        public Color physicalColor = BattleConstants.PHYSICAL_COLOR;
        public Color specialColor = BattleConstants.SPECIAL_COLOR;
        public Color statusColor = BattleConstants.STATUS_COLOR;

        private List<SkillTooltip> _skillTooltips = new List<SkillTooltip>();
        private ObjectPool<DamageTextPop> _damageTextPool;

        void Awake()
        {
            InitializeUI();
            InitializeObjectPool();
            SubscribeToEvents();
            AutoBindButtonEvents();
        }

        void Start()
        {
            InitializeSkillTooltips();
        }

        void OnDestroy()
        {
            UnsubscribeFromEvents();
        }

        private void InitializeUI()
        {
            if (descriptionTooltipText != null)
            {
                descriptionTooltipText.gameObject.SetActive(false);
            }
        }

        private void AutoBindButtonEvents()
        {
            if (skillButtons == null)
            {
                Debug.LogWarning("AutoBindButtonEvents: skillButtons����Ϊ��");
                return;
            }

            for (int i = 0; i < skillButtons.Length; i++)
            {
                Button btn = skillButtons[i];
                if (btn == null) continue;

                btn.onClick.RemoveAllListeners();
                int skillIndex = i;

                btn.onClick.AddListener(() =>
                {
                    BattleController controller = BattleController.Instance;
                    if (controller != null)
                    {
                        Debug.Log($"�����ť{skillIndex}�����ü�������{skillIndex}");
                        controller.OnPlayerUseSkill(skillIndex);
                    }
                    else
                    {
                        Debug.LogWarning($"BattleController.InstanceΪ�գ��޷����ü���{skillIndex}");
                    }
                });

                Debug.Log($"�Զ��󶨰�ť{i}����������{skillIndex}");
            }
        }

        private void InitializeObjectPool()
        {
            if (damageTextPrefab != null && damageCanvas != null)
            {
                _damageTextPool = new ObjectPool<DamageTextPop>(
                    createFunc: () => Instantiate(damageTextPrefab, damageCanvas).GetComponent<DamageTextPop>(),
                    actionOnGet: (obj) => obj.gameObject.SetActive(true),
                    actionOnRelease: (obj) => obj.gameObject.SetActive(false),
                    actionOnDestroy: (obj) => Destroy(obj.gameObject),
                    defaultCapacity: 10,
                    maxSize: 50
                );
            }
            else
            {
                Debug.LogWarning("DamageTextPrefab��DamageCanvasδ���ã������δ��ʼ��");
            }
        }

        // ����������߼��޸������Ӷ�OnHealReceived�ļ���
        private void SubscribeToEvents()
        {
            BattleEvents.OnSkillButtonsUpdateNeeded += OnSkillButtonsUpdateNeeded;
            BattleEvents.OnDamageDealt += OnDamageDealt;
            // �����������������¼�
            BattleEvents.OnHealReceived += OnHealReceived;
        }

        // ����������߼��޸���ȡ������
        private void UnsubscribeFromEvents()
        {
            BattleEvents.OnSkillButtonsUpdateNeeded -= OnSkillButtonsUpdateNeeded;
            BattleEvents.OnDamageDealt -= OnDamageDealt;
            // ��������ȡ������
            BattleEvents.OnHealReceived -= OnHealReceived;
        }

        // ��ʼ��UI
        public void InitializeUI(PetEntity playerPet)
        {
            if (playerPet != null)
            {
                UpdateSkillButtons(playerPet);
            }
            else
            {
                Debug.LogWarning("InitializeUI: playerPetΪ��");
            }
        }

        // ���¼��ܰ�ť
        private void OnSkillButtonsUpdateNeeded(PetEntity pet)
        {
            UpdateSkillButtons(pet);
        }

        public void UpdateSkillButtons(PetEntity playerPet)
        {
            if (playerPet == null)
            {
                Debug.LogError("UpdateSkillButtons: playerPet is null!");
                return;
            }

            if (skillButtons == null)
            {
                Debug.LogError("UpdateSkillButtons: skillButtons array is null!");
                return;
            }

            int skillCount = playerPet.skills != null ? playerPet.skills.Count : 0;
            Debug.Log($"���¼��ܰ�ť: ������ {skillCount} ������, UI�� {skillButtons.Length} ����ť");

            for (int i = 0; i < skillButtons.Length; i++)
            {
                if (skillButtons[i] == null)
                {
                    Debug.LogWarning($"���ܰ�ť {i} Ϊ��!");
                    continue;
                }

                if (i < skillCount && playerPet.skills[i] != null)
                {
                    SkillData skill = playerPet.skills[i];

                    skillButtons[i].gameObject.SetActive(true);
                    skillButtons[i].interactable = (skill.currentPP > 0);

                    if (skillButtonTexts != null && i < skillButtonTexts.Length)
                    {
                        TextMeshProUGUI textComp = skillButtonTexts[i];
                        if (textComp != null)
                        {
                            string categoryTag = GetCategoryTag(skill.category);
                            string displayText = $"{skill.skillName}\n";

                            if (skill.power > 0)
                            {
                                displayText += $"����: {skill.power}\n";
                            }

                            if (skill.maxPP > 0)
                            {
                                if (skill.currentPP <= 0)
                                    displayText += $"<color=red>({skill.currentPP}/{skill.maxPP})</color>";
                                else
                                    displayText += $"<color=#FFD700>({skill.currentPP}/{skill.maxPP})</color>";
                            }

                            if (!string.IsNullOrEmpty(skill.element) && skill.element != "��")
                            {
                                displayText += $"\n[{skill.element}] {categoryTag}";
                            }
                            else
                            {
                                displayText += $"\n{categoryTag}";
                            }

                            textComp.text = displayText;
                        }
                    }

                    if (skillButtonIcons != null && i < skillButtonIcons.Length && skillButtonIcons[i] != null)
                    {
                        if (skill.icon != null)
                        {
                            skillButtonIcons[i].sprite = skill.icon;
                        }
                    }

                    if (_skillTooltips != null && i < _skillTooltips.Count && _skillTooltips[i] != null)
                    {
                        _skillTooltips[i].skillDescription = skill.description;
                        _skillTooltips[i].skillDetails = $"����: {skill.power} | ����: {skill.accuracy} | PP: {skill.currentPP}/{skill.maxPP}";
                    }
                }
                else
                {
                    skillButtons[i].gameObject.SetActive(true);
                    skillButtons[i].interactable = false;

                    if (skillButtonTexts != null && i < skillButtonTexts.Length && skillButtonTexts[i] != null)
                    {
                        skillButtonTexts[i].text = "�޼���";
                        skillButtonTexts[i].color = Color.gray;
                    }
                }
            }

            Debug.Log("���ܰ�ť�������");
        }

        // ���ü��ܰ�ť����״̬
        public void SetSkillButtonsInteractable(bool interactable)
        {
            if (skillButtons == null)
            {
                Debug.LogWarning("SetSkillButtonsInteractable: skillButtons ����Ϊ��!");
                return;
            }

            foreach (Button btn in skillButtons)
            {
                if (btn != null && btn.gameObject.activeSelf)
                {
                    btn.interactable = interactable;
                }
            }

            Debug.Log($"���ܰ�ť����״̬����Ϊ: {interactable}");
        }

        // �����˺���ʾ
        private void OnDamageDealt(PetEntity attacker, PetEntity target, SkillData skill, int damage)
        {
            if (target == null)
            {
                Debug.LogWarning("OnDamageDealt: Ŀ��Ϊ��");
                return;
            }

            if (damageCanvas == null)
            {
                Debug.LogWarning("OnDamageDealt: DamageCanvasΪ��");
                return;
            }

            if (_damageTextPool == null)
            {
                Debug.LogWarning("OnDamageDealt: �˺����ֶ����δ��ʼ��");
                return;
            }

            DamageTextPop damageText = _damageTextPool.Get();

            if (damageText != null)
            {
                RectTransform targetRect = target.GetComponent<RectTransform>();
                if (targetRect != null)
                {
                    Vector3 targetPosition = targetRect.position;
                    Vector3 offset = new Vector3(
                        Random.Range(-50f, 50f),
                        Random.Range(50f, 100f),
                        0
                    );
                    damageText.transform.position = targetPosition + offset;
                }
                else
                {
                    damageText.transform.position = new Vector3(Screen.width / 2, Screen.height / 2, 0);
                }

                DamageTextPop.DamageType damageType = DamageTextPop.DamageType.Normal;

                if (skill != null && skill.effectType == SkillEffectType.GuaranteedCrit)
                {
                    damageType = DamageTextPop.DamageType.Critical;
                }

                damageText.ShowDamage(damage, damageType);

                StartCoroutine(ReturnToPoolAfterDelay(damageText, 3f));

                Debug.Log($"�� {target.petName} λ����ʾ�˺�����: {damage}");
            }
        }

        // ����������߼��޸�����������������ʾ�ķ���
        private void OnHealReceived(PetEntity target, int amount)
        {
            if (target == null || amount <= 0) return;

            // �Ӷ���ػ�ȡƮ�����
            if (_damageTextPool != null)
            {
                DamageTextPop damageText = _damageTextPool.Get();

                // ����λ�ã�������֮ǰ���߼���
                RectTransform targetRect = target.GetComponent<RectTransform>();
                if (targetRect != null)
                {
                    Vector3 offset = new Vector3(Random.Range(-30f, 30f), Random.Range(50f, 80f), 0);
                    damageText.transform.position = targetRect.position + offset;
                }

                // ��ʾΪ�������ͣ���ɫ��
                damageText.ShowDamage(amount, DamageTextPop.DamageType.Heal);

                // 3������
                StartCoroutine(ReturnToPoolAfterDelay(damageText, 3f));
            }
        }

        private IEnumerator ReturnToPoolAfterDelay(DamageTextPop damageText, float delay)
        {
            yield return new WaitForSeconds(delay);

            if (damageText != null && _damageTextPool != null)
            {
                _damageTextPool.Release(damageText);
            }
        }

        // ��ȡ�����ǩ - ֧�����ķ���
        private string GetCategoryTag(string category)
        {
            if (string.IsNullOrEmpty(category))
            {
                return "[δ֪]";
            }

            string cat = category.Trim();

            if (cat.Contains("����") || cat == "����" || cat == BattleConstants.CATEGORY_PHYSICAL || cat.ToLower() == "physical")
                return "[����]";
            else if (cat.Contains("�ع�") || cat == "�ع�" || cat == BattleConstants.CATEGORY_SPECIAL || cat.ToLower() == "special")
                return "[�ع�]";
            else if (cat.Contains("����") || cat == "����" || cat == BattleConstants.CATEGORY_STATUS ||
                     cat == "����" || cat == "����" || cat.ToLower() == "status")
                return "[����]";
            else
                return $"[{category}]";
        }

        // ��ʼ�����ܹ�����ʾ
        private void InitializeSkillTooltips()
        {
            _skillTooltips.Clear();

            if (skillButtons == null)
            {
                Debug.LogWarning("InitializeSkillTooltips: skillButtons����Ϊ��");
                return;
            }

            for (int i = 0; i < skillButtons.Length; i++)
            {
                if (skillButtons[i] != null)
                {
                    SkillTooltip tooltip = skillButtons[i].GetComponent<SkillTooltip>();
                    if (tooltip == null)
                    {
                        tooltip = skillButtons[i].gameObject.AddComponent<SkillTooltip>();
                        Debug.Log($"Ϊ��ť{i}����SkillTooltip���");
                    }

                    if (descriptionTooltipText != null)
                    {
                        tooltip.descriptionText = descriptionTooltipText;
                    }

                    _skillTooltips.Add(tooltip);
                }
            }
        }
    }
}