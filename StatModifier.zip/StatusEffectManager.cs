using System.Collections.Generic;
using UnityEngine;

namespace BattleSystem
{
    /// <summary>
    /// �������г�����쳣״̬
    /// </summary>
    public class StatusEffectManager : MonoBehaviour
    {
        private Dictionary<PetEntity, List<StatusEffect>> _petStatusEffects = new Dictionary<PetEntity, List<StatusEffect>>();

        public static StatusEffectManager Instance { get; private set; }

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        /// <summary>
        /// ����״̬Ч��
        /// </summary>
        public bool AddStatusEffect(PetEntity target, StatusEffect newEffect)
        {
            if (target == null || target.isDead) return false;

            // ����Ƿ����߸�״̬
            if (target.IsImmuneTo(newEffect.condition))
            {
                Debug.Log($"{target.petName} ���� {newEffect.condition} ״̬");
                return false;
            }

            // �������ȡ�ó����״̬�б�
            if (!_petStatusEffects.TryGetValue(target, out var effects))
            {
                effects = new List<StatusEffect>();
                _petStatusEffects[target] = effects;
            }

            // ����Ƿ��Ѵ�����ͬ״̬
            var existingEffect = effects.Find(e => e.condition == newEffect.condition);

            if (existingEffect != null)
            {
                if (StatusEffectConfig.IsStackable(newEffect.condition))
                {
                    // ���ڼ���״̬������ֻˢ�³���ʱ�䣬�����Ӳ���
                    if (newEffect.condition == StatusCondition.Parasitic)
                    {
                        existingEffect.remainingTurns = Mathf.Max(existingEffect.remainingTurns, newEffect.remainingTurns);
                        Debug.Log($"{target.petName} �� {newEffect.condition} ״̬����ʱ��ˢ��Ϊ {existingEffect.remainingTurns} �غ�");
                    }
                    else
                    {
                        // �����ɵ���״̬�����Ӳ���
                        existingEffect.stackCount++;
                        existingEffect.remainingTurns = Mathf.Max(existingEffect.remainingTurns, newEffect.remainingTurns);
                        Debug.Log($"{target.petName} �� {newEffect.condition} ״̬������ {existingEffect.stackCount} ��");
                    }

                    // ����״̬�����¼�
                    BattleEvents.TriggerStatusEffectUpdated(target, existingEffect);
                    return true;
                }
                else
                {
                    // ���ɵ���״̬��ˢ�³���ʱ�䣬�������������¼�
                    existingEffect.remainingTurns = Mathf.Max(existingEffect.remainingTurns, newEffect.remainingTurns);
                    Debug.Log($"{target.petName} �� {newEffect.condition} ״̬����ʱ��ˢ��Ϊ {existingEffect.remainingTurns} �غ�");

                    // ����״̬�����¼�
                    BattleEvents.TriggerStatusEffectUpdated(target, existingEffect);
                    return true;
                }
            }
            else
            {
                // �����״̬������״̬�Ƿ���Թ���
                bool canCoexist = true;
                foreach (var effect in effects)
                {
                    if (!StatusEffectConfig.CanCoexist(effect.condition, newEffect.condition))
                    {
                        canCoexist = false;
                        break;
                    }
                }

                if (!canCoexist)
                {
                    Debug.Log($"{target.petName} ����ͬʱӵ�� {newEffect.condition} ״̬������״̬");
                    return false;
                }

                // ������״̬
                effects.Add(newEffect);
                Debug.Log($"{target.petName} ��� {newEffect.condition} ״̬������ {newEffect.remainingTurns} �غ�");

                // ����״̬�����¼�
                BattleEvents.TriggerStatusEffectApplied(target, newEffect);
                return true;
            }
        }

        /// <summary>
        /// �Ƴ�״̬Ч��
        /// </summary>
        public void RemoveStatusEffect(PetEntity target, StatusCondition condition)
        {
            if (_petStatusEffects.TryGetValue(target, out var effects))
            {
                var effect = effects.Find(e => e.condition == condition);
                if (effect != null)
                {
                    effects.Remove(effect);
                    Debug.Log($"{target.petName} �� {condition} ״̬���Ƴ�");

                    // ����״̬�Ƴ��¼�
                    BattleEvents.TriggerStatusEffectRemoved(target, condition);
                }

                if (effects.Count == 0)
                {
                    _petStatusEffects.Remove(target);
                }
            }
        }

        /// <summary>
        /// �������״̬Ч��
        /// </summary>
        public void ClearAllStatusEffects(PetEntity target)
        {
            if (_petStatusEffects.ContainsKey(target))
            {
                // ��������״̬�Ƴ��¼�
                foreach (var effect in _petStatusEffects[target])
                {
                    BattleEvents.TriggerStatusEffectRemoved(target, effect.condition);
                }

                _petStatusEffects.Remove(target);
                Debug.Log($"{target.petName} ������״̬Ч�������");
            }
        }

        /// <summary>
        /// ����ض����͵�״̬Ч��
        /// </summary>
        public void ClearStatusEffectsOfType(PetEntity target, StatusCondition condition)
        {
            if (_petStatusEffects.TryGetValue(target, out var effects))
            {
                effects.RemoveAll(e => e.condition == condition);
                Debug.Log($"{target.petName} ������ {condition} ״̬�����");

                BattleEvents.TriggerStatusEffectRemoved(target, condition);

                if (effects.Count == 0)
                {
                    _petStatusEffects.Remove(target);
                }
            }
        }

        /// <summary>
        /// ��ȡ�����״̬Ч��
        /// </summary>
        public List<StatusEffect> GetStatusEffects(PetEntity target)
        {
            return _petStatusEffects.TryGetValue(target, out var effects) ? effects : new List<StatusEffect>();
        }

        /// <summary>
        /// ����Ƿ�ӵ���ض�״̬
        /// </summary>
        public bool HasStatus(PetEntity target, StatusCondition condition)
        {
            if (_petStatusEffects.TryGetValue(target, out var effects))
            {
                return effects.Exists(e => e.condition == condition);
            }
            return false;
        }

        /// <summary>
        /// ��ȡ״̬����
        /// </summary>
        public int GetStatusStackCount(PetEntity target, StatusCondition condition)
        {
            if (_petStatusEffects.TryGetValue(target, out var effects))
            {
                var effect = effects.Find(e => e.condition == condition);
                return effect?.stackCount ?? 0;
            }
            return 0;
        }

        /// <summary>
        /// �����غϿ�ʼʱ��״̬Ч��
        /// </summary>
        public void ProcessTurnStart(PetEntity pet)
        {
            if (!_petStatusEffects.TryGetValue(pet, out var effects)) return;

            // �������״̬�����Ƿ�����ж�
            foreach (var effect in effects)
            {
                if (!effect.CanTakeAction())
                {
                    Debug.Log($"{pet.petName} �� {effect.condition} ״̬�޷��ж�");
                    BattleEvents.TriggerActionPrevented(pet, effect.condition);
                    return; // ֻҪ��һ��״̬��ֹ�ж������޷��ж�
                }
            }
        }

        /// <summary>
        /// �����غϽ���ʱ��״̬Ч��
        /// </summary>
        public void ProcessTurnEnd(PetEntity pet)
        {
            if (!_petStatusEffects.TryGetValue(pet, out var effects)) return;

            List<StatusEffect> effectsToRemove = new List<StatusEffect>();

            foreach (var effect in effects)
            {
                // ��������˺�
                int damage = effect.CalculateTurnDamage(pet);
                if (damage > 0)
                {
                    pet.TakeDamage(damage);
                    Debug.Log($"{pet.petName} �� {effect.condition} ״̬�ܵ� {damage} ���˺�");

                    // ����״̬�˺��¼�
                    BattleEvents.TriggerStatusDamageTick(pet, effect.condition, damage);

                    // ����Ǽ���������ʩ����
                    if (effect.condition == StatusCondition.Parasitic && !string.IsNullOrEmpty(effect.sourcePetId))
                    {
                        PetEntity sourcePet = FindPetById(effect.sourcePetId);
                        if (sourcePet != null && !sourcePet.isDead)
                        {
                            sourcePet.Heal(damage);
                            Debug.Log($"{sourcePet.petName} ͨ�������������� {damage} ������ֵ");
                        }
                    }
                }

                // �غϽ�������
                effect.OnTurnEnd(pet);

                // ���״̬�Ƿ����
                if (effect.remainingTurns <= 0)
                {
                    effectsToRemove.Add(effect);
                }
            }

            // �Ƴ��ѽ�����״̬
            foreach (var effect in effectsToRemove)
            {
                RemoveStatusEffect(pet, effect.condition);
            }
        }

        /// <summary>
        /// ��ȡ״̬�Թ������ĳ���������״̬���ӣ�
        /// </summary>
        public float GetStatusAttackMultiplier(PetEntity attacker)
        {
            if (!_petStatusEffects.TryGetValue(attacker, out var effects)) return 1.0f;

            float multiplier = 1.0f;
            foreach (var effect in effects)
            {
                multiplier *= effect.GetAttackMultiplier();
            }
            return multiplier;
        }

        /// <summary>
        /// ��ȡ״̬�������ʵĳ���������״̬���ӣ�
        /// </summary>
        public float GetStatusAccuracyMultiplier(PetEntity attacker)
        {
            if (!_petStatusEffects.TryGetValue(attacker, out var effects)) return 1.0f;

            float multiplier = 1.0f;
            foreach (var effect in effects)
            {
                multiplier *= effect.GetAccuracyMultiplier();
            }
            return multiplier;
        }

        /// <summary>
        /// ��ȡ״̬������Ч���ĳ���������״̬���ӣ�
        /// </summary>
        public float GetStatusHealMultiplier(PetEntity target)
        {
            if (!_petStatusEffects.TryGetValue(target, out var effects)) return 1.0f;

            float multiplier = 1.0f;
            foreach (var effect in effects)
            {
                multiplier *= effect.GetHealMultiplier();
            }
            return multiplier;
        }

        /// <summary>
        /// ����Ƿ�ṥ���Լ�������״̬��
        /// </summary>
        public bool ShouldAttackSelf(PetEntity attacker)
        {
            if (!_petStatusEffects.TryGetValue(attacker, out var effects)) return false;

            foreach (var effect in effects)
            {
                if (effect.WillAttackSelf())
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// ����Ƿ�����ж�����������״̬��
        /// </summary>
        public bool CanPetTakeAction(PetEntity pet)
        {
            if (!_petStatusEffects.TryGetValue(pet, out var effects)) return true;

            foreach (var effect in effects)
            {
                if (!effect.CanTakeAction())
                {
                    return false;
                }
            }
            return true;
        }

        private PetEntity FindPetById(string petId)
        {
            // ������Ը�����ĳ���ID�����߼�������
            // ʾ��������ʵ��ID����
            var pets = FindObjectsOfType<PetEntity>();
            foreach (var pet in pets)
            {
                if (pet.GetInstanceID().ToString() == petId)
                    return pet;
            }
            return null;
        }

        /// <summary>
        /// ��ȡ�����״̬Ч���ı�����
        /// </summary>
        public string GetStatusEffectsText(PetEntity pet)
        {
            if (!_petStatusEffects.TryGetValue(pet, out var effects) || effects.Count == 0)
                return "���쳣״̬";

            string result = "";
            foreach (var effect in effects)
            {
                result += effect.GetDisplayText() + " ";
            }
            return result.Trim();
        }
    }
}