using System;

namespace BattleSystem
{
    [Serializable]
    public struct StatModifier
    {
        public BattleConstants.StatType statType;
        public int value;
        public bool isPercentage;

        public StatModifier(BattleConstants.StatType type, int val, bool isPercent = false)
        {
            statType = type;
            value = val;
            isPercentage = isPercent;
        }

        public override string ToString()
        {
            string statName = GetStatName(statType);
            string sign = value > 0 ? "+" : "";
            return $"{statName}{sign}{value}{(isPercentage ? "%" : "")}";
        }

        private static string GetStatName(BattleConstants.StatType type)
        {
            return type switch
            {
                BattleConstants.StatType.Attack => "����",
                BattleConstants.StatType.MagicAttack => "�ع�",
                BattleConstants.StatType.Defense => "����",
                BattleConstants.StatType.MagicDefense => "�ط�",
                BattleConstants.StatType.Speed => "�ٶ�",
                BattleConstants.StatType.Critical => "����",
                _ => "δ֪"
            };
        }
    }
}