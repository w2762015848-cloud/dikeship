using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BattleSystem
{
    [RequireComponent(typeof(PetUI))]
    public class PetEntity : MonoBehaviour
    {
        [Header("������Ϣ")]
        public string petName = "����";
        public string element = BattleConstants.ELEMENT_NONE;

        [Header("��������")]
        [SerializeField] private int _maxHP = 100;
        [SerializeField] private int _currentHP = 100;
        public int attack = 80;
        public int magicAttack = 90;
        public int defense = 70;
        public int magicDefense = 80;
        public int speed = 100;

        [Header("�����ȼ�")]
        [Range(BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL)]
        public int attackLevel = 0;
        [Range(BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL)]
        public int magicAttackLevel = 0;
        [Range(BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL)]
        public int defenseLevel = 0;
        [Range(BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL)]
        public int magicDefenseLevel = 0;
        [Range(BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL)]
        public int speedLevel = 0;
        [Range(BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL)]
        public int criticalLevel = 0;

        [Header("����")]
        public List<SkillData> skills = new List<SkillData>();
        public SkillData passiveSkill;

        [Header("״̬")]
        public bool isDead = false;
        public bool isStunned = false;

        [Header("״̬����")]
        public List<StatusCondition> immunities = new List<StatusCondition>();

        // ���Է�����
        public int MaxHP => _maxHP;
        public int CurrentHP => _currentHP;

        private PetUI _petUI;

        // ��ȡʵ������ֵ�������ȼ�������
        public float GetAttack(bool isPhysical)
        {
            float baseValue = isPhysical ? attack : magicAttack;
            float levelMultiplier = 1 + (isPhysical ? attackLevel : magicAttackLevel) * BattleConstants.STAT_LEVEL_MULTIPLIER;
            return baseValue * levelMultiplier;
        }

        public float GetDefense(bool isPhysical)
        {
            float baseValue = isPhysical ? defense : magicDefense;
            float levelMultiplier = 1 + (isPhysical ? defenseLevel : magicDefenseLevel) * BattleConstants.STAT_LEVEL_MULTIPLIER;
            return baseValue * levelMultiplier;
        }

        // �ܵ��˺�
        public void TakeDamage(int damage)
        {
            if (isDead) return;

            int oldHP = _currentHP;
            _currentHP = Mathf.Clamp(_currentHP - damage, 0, _maxHP);

            if (_currentHP <= 0)
            {
                _currentHP = 0;
                isDead = true;
                BattleEvents.TriggerPetDeath(this);
            }

            BattleEvents.TriggerPetHPChanged(this, _currentHP, _maxHP);
            BattleEvents.TriggerPetUIUpdateNeeded(this);
        }

        // ����
        public void Heal(int amount)
        {
            if (isDead) return;

            // Ӧ��״̬�����Ƶ�����
            float healMultiplier = 1.0f;
            var statusManager = StatusEffectManager.Instance;
            if (statusManager != null)
            {
                healMultiplier = statusManager.GetStatusHealMultiplier(this);
            }

            int finalHeal = Mathf.RoundToInt(amount * healMultiplier);
            int oldHP = _currentHP;
            _currentHP = Mathf.Clamp(_currentHP + finalHeal, 0, _maxHP);

            BattleEvents.TriggerPetHPChanged(this, _currentHP, _maxHP);
            BattleEvents.TriggerHealReceived(this, finalHeal);
            BattleEvents.TriggerPetUIUpdateNeeded(this);

            if (healMultiplier < 1.0f)
            {
                Debug.Log($"{petName} ���쳣״̬����Ч�����룬ʵ������{finalHeal}��");
            }
        }

        // �޸������ȼ�
        public void ModifyStat(BattleConstants.StatType statType, int change)
        {
            change = Mathf.Clamp(change, BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL);

            switch (statType)
            {
                case BattleConstants.StatType.Attack:
                    attackLevel = Mathf.Clamp(attackLevel + change, BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL);
                    break;
                case BattleConstants.StatType.MagicAttack:
                    magicAttackLevel = Mathf.Clamp(magicAttackLevel + change, BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL);
                    break;
                case BattleConstants.StatType.Defense:
                    defenseLevel = Mathf.Clamp(defenseLevel + change, BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL);
                    break;
                case BattleConstants.StatType.MagicDefense:
                    magicDefenseLevel = Mathf.Clamp(magicDefenseLevel + change, BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL);
                    break;
                case BattleConstants.StatType.Speed:
                    speedLevel = Mathf.Clamp(speedLevel + change, BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL);
                    break;
                case BattleConstants.StatType.Critical:
                    criticalLevel = Mathf.Clamp(criticalLevel + change, BattleConstants.MIN_STAT_LEVEL, BattleConstants.MAX_STAT_LEVEL);
                    break;
            }

            BattleEvents.TriggerPetStatChanged(this, statType, change);
        }

        // ����״̬
        public void ResetState()
        {
            _currentHP = _maxHP;
            isDead = false;
            isStunned = false;

            attackLevel = 0;
            magicAttackLevel = 0;
            defenseLevel = 0;
            magicDefenseLevel = 0;
            speedLevel = 0;
            criticalLevel = 0;

            // ���ü���PP
            foreach (var skill in skills)
            {
                if (skill != null)
                    skill.ResetPP();
            }

            // ���״̬Ч��
            var statusManager = StatusEffectManager.Instance;
            if (statusManager != null)
            {
                statusManager.ClearAllStatusEffects(this);
            }

            BattleEvents.TriggerPetUIUpdateNeeded(this);
        }

        // ����HP�����ڳ�ʼ����
        public void SetHP(int hp, int maxHP)
        {
            _currentHP = Mathf.Clamp(hp, 0, maxHP);
            _maxHP = Mathf.Max(1, maxHP);
            BattleEvents.TriggerPetHPChanged(this, _currentHP, _maxHP);
        }

        // ����Ƿ�����ĳ��״̬
        public bool IsImmuneTo(StatusCondition condition)
        {
            // ���Ԫ������
            switch (condition)
            {
                case StatusCondition.Burn:
                    return element == BattleConstants.ELEMENT_FIRE;

                case StatusCondition.Freeze:
                    return element == BattleConstants.ELEMENT_WATER;

                case StatusCondition.Paralyze:
                    return element == BattleConstants.ELEMENT_ELECTRIC;

                case StatusCondition.Poison:
                    return element == BattleConstants.ELEMENT_POISON ||
                           element == BattleConstants.ELEMENT_MECH;
            }

            // ����Զ��������б�
            return immunities.Contains(condition);
        }

        void Awake()
        {
            _petUI = GetComponent<PetUI>();
            if (_petUI == null)
            {
                _petUI = gameObject.AddComponent<PetUI>();
            }
        }

        void Start()
        {
            BattleEvents.TriggerPetHPChanged(this, _currentHP, _maxHP);
        }
    }
}