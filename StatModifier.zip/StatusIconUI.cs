using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace BattleSystem
{
    public class StatusIconUI : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        [Header("UI����")]
        public Image statusIcon;
        public TextMeshProUGUI stackText;
        public GameObject tooltipPrefab;

        [Header("״̬����")]
        public StatusCondition condition;
        public int remainingTurns;
        public int stackCount = 1;

        private GameObject _tooltipInstance;
        private PetEntity _ownerPet;
        private Canvas _rootCanvas; // �洢����������

        void Awake()
        {
            // ���Ҹ�����
            if (_rootCanvas == null)
            {
                Transform current = transform;
                while (current != null)
                {
                    Canvas canvas = current.GetComponent<Canvas>();
                    if (canvas != null && canvas.isRootCanvas)
                    {
                        _rootCanvas = canvas;
                        break;
                    }
                    current = current.parent;
                }

                if (_rootCanvas == null)
                {
                    _rootCanvas = FindObjectOfType<Canvas>();
                }
            }
        }

        public void Initialize(StatusCondition condition, int remainingTurns, int stackCount, PetEntity owner)
        {
            this.condition = condition;
            this.remainingTurns = remainingTurns;
            this.stackCount = stackCount;
            _ownerPet = owner;

            UpdateDisplay();
        }

        public void UpdateDisplay()
        {
            // ���²�����ʾ
            if (stackCount > 1 && stackText != null)
            {
                stackText.text = stackCount.ToString();
                stackText.gameObject.SetActive(true);

                // ȷ������������ȷ
                if (stackText.font == null)
                {
                    // �������Ϊ�գ���������Ĭ������
                    TMP_FontAsset defaultFont = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
                    if (defaultFont != null)
                    {
                        stackText.font = defaultFont;
                    }
                }
            }
            else if (stackText != null)
            {
                stackText.gameObject.SetActive(false);
            }
        }

        public void UpdateStatus(int newRemainingTurns, int newStackCount)
        {
            remainingTurns = newRemainingTurns;
            stackCount = newStackCount;
            UpdateDisplay();
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            ShowTooltip();
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            HideTooltip();
        }

        private void ShowTooltip()
        {
            if (tooltipPrefab == null || _ownerPet == null || condition == StatusCondition.None)
            {
                Debug.LogWarning("�޷���ʾ������ʾ��ȱ�ٱ�Ҫ���");
                return;
            }

            // �������й�����ʾ
            if (_tooltipInstance != null)
            {
                Destroy(_tooltipInstance);
            }

            if (_rootCanvas == null)
            {
                Debug.LogWarning("�޷��ҵ���Canvas");
                return;
            }

            // ����������ʾʵ��
            _tooltipInstance = Instantiate(tooltipPrefab, _rootCanvas.transform);
            _tooltipInstance.transform.SetAsLastSibling(); // ȷ�������ϲ�

            // ���ù�����ʾ����
            StatusTooltip tooltip = _tooltipInstance.GetComponent<StatusTooltip>();
            if (tooltip != null)
            {
                string statusName = StatusEffectConfig.GetDisplayName(condition);
                string description = GetStatusDescription(condition);
                string tooltipText = $"<b>{statusName}</b>\n{description}";

                if (remainingTurns > 0)
                {
                    tooltipText += $"\nʣ��غ�: {remainingTurns}";
                }

                if (stackCount > 1)
                {
                    tooltipText += $"\n����: {stackCount}";
                }

                tooltip.SetText(tooltipText);

                // ����λ�� - ʹ����Ļ����
                Vector3 iconScreenPos = RectTransformUtility.WorldToScreenPoint(null, transform.position);
                Vector2 localPoint;

                RectTransform canvasRect = _rootCanvas.GetComponent<RectTransform>();
                if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    canvasRect,
                    iconScreenPos,
                    null,
                    out localPoint))
                {
                    tooltip.SetPosition(localPoint + new Vector2(0, 60));
                }

                tooltip.Show();
            }

            Debug.Log($"��ʾ״̬������ʾ: {condition}");
        }

        private string GetStatusDescription(StatusCondition condition)
        {
            return condition switch
            {
                StatusCondition.Burn => "ÿ�غ���ʧ�������ֵ��10%������������10%",
                StatusCondition.Freeze => "�޷��ж�",
                StatusCondition.Paralyze => "25%�����޷��ж�",
                StatusCondition.Poison => "ÿ�غ���ʧ�������ֵ��10%������Ч������",
                StatusCondition.Blind => "�����ʽ���50%",
                StatusCondition.Confusion => "40%���ʹ����Լ�",
                StatusCondition.Parasitic => "ÿ�غ���ʧ�������ֵ��8%��ʩ���߻�õ�������",
                StatusCondition.Stun => "�޷��ж�",
                _ => "��Ч��"
            };
        }

        private void HideTooltip()
        {
            if (_tooltipInstance != null)
            {
                StatusTooltip tooltip = _tooltipInstance.GetComponent<StatusTooltip>();
                if (tooltip != null)
                {
                    tooltip.Hide();
                    // �ȴ�����������ɺ�����
                    Destroy(_tooltipInstance, 0.5f);
                }
                else
                {
                    Destroy(_tooltipInstance);
                }
                _tooltipInstance = null;
            }
        }

        void OnDisable()
        {
            HideTooltip();
        }

        void OnDestroy()
        {
            if (_tooltipInstance != null)
            {
                Destroy(_tooltipInstance);
            }
        }
    }
}