using System;

namespace BattleSystem
{
    public static class BattleEvents
    {
        // ս���¼�
        public static event Action OnBattleStart;
        public static event Action OnBattleEnd;
        public static event Action OnTurnStart;
        public static event Action OnTurnEnd;

        // �����¼�
        public static event Action<PetEntity, int, int> OnPetHPChanged; // �����ǰHP�����HP
        public static event Action<PetEntity> OnPetDeath;
        public static event Action<PetEntity> OnPetRevive;
        public static event Action<PetEntity, BattleConstants.StatType, int> OnPetStatChanged; // ���״̬���ͣ��仯ֵ

        // �����¼�
        public static event Action<PetEntity, SkillData> OnSkillUsed;
        public static event Action<PetEntity, PetEntity, SkillData, int> OnDamageDealt; // �����ߣ�Ŀ�꣬���ܣ��˺���
        public static event Action<PetEntity, int> OnHealReceived; // Ŀ�꣬������

        // UI�¼�
        public static event Action<PetEntity> OnPetUIUpdateNeeded;
        public static event Action<PetEntity> OnSkillButtonsUpdateNeeded;

        // �쳣״̬�¼�
        public static event Action<PetEntity, StatusEffect> OnStatusEffectApplied;
        public static event Action<PetEntity, StatusCondition> OnStatusEffectRemoved;
        public static event Action<PetEntity, StatusEffect> OnStatusEffectUpdated;
        public static event Action<PetEntity, StatusCondition> OnActionPrevented;
        public static event Action<PetEntity, StatusCondition, int> OnStatusDamageTick;

        // ��������
        public static void TriggerBattleStart() => OnBattleStart?.Invoke();
        public static void TriggerBattleEnd() => OnBattleEnd?.Invoke();
        public static void TriggerTurnStart() => OnTurnStart?.Invoke();
        public static void TriggerTurnEnd() => OnTurnEnd?.Invoke();

        public static void TriggerPetHPChanged(PetEntity pet, int currentHP, int maxHP) =>
            OnPetHPChanged?.Invoke(pet, currentHP, maxHP);

        public static void TriggerPetDeath(PetEntity pet) => OnPetDeath?.Invoke(pet);
        public static void TriggerPetRevive(PetEntity pet) => OnPetRevive?.Invoke(pet);

        public static void TriggerPetStatChanged(PetEntity pet, BattleConstants.StatType statType, int change) =>
            OnPetStatChanged?.Invoke(pet, statType, change);

        public static void TriggerSkillUsed(PetEntity attacker, SkillData skill) =>
            OnSkillUsed?.Invoke(attacker, skill);

        public static void TriggerDamageDealt(PetEntity attacker, PetEntity target, SkillData skill, int damage) =>
            OnDamageDealt?.Invoke(attacker, target, skill, damage);

        public static void TriggerHealReceived(PetEntity target, int amount) =>
            OnHealReceived?.Invoke(target, amount);

        public static void TriggerPetUIUpdateNeeded(PetEntity pet) =>
            OnPetUIUpdateNeeded?.Invoke(pet);

        public static void TriggerSkillButtonsUpdateNeeded(PetEntity pet) =>
            OnSkillButtonsUpdateNeeded?.Invoke(pet);

        public static void TriggerStatusEffectApplied(PetEntity pet, StatusEffect effect) =>
            OnStatusEffectApplied?.Invoke(pet, effect);

        public static void TriggerStatusEffectRemoved(PetEntity pet, StatusCondition condition) =>
            OnStatusEffectRemoved?.Invoke(pet, condition);

        public static void TriggerStatusEffectUpdated(PetEntity pet, StatusEffect effect) =>
            OnStatusEffectUpdated?.Invoke(pet, effect);

        public static void TriggerActionPrevented(PetEntity pet, StatusCondition condition) =>
            OnActionPrevented?.Invoke(pet, condition);

        public static void TriggerStatusDamageTick(PetEntity pet, StatusCondition condition, int damage) =>
            OnStatusDamageTick?.Invoke(pet, condition, damage);
    }
}