using UnityEngine;

namespace BattleSystem
{
    public class BattleDebugger : MonoBehaviour
    {
        [Header("��������")]
        public bool enableDebugging = true;

        private BattleController _battleController;
        private BattleUIController _uiController;

        void Awake()
        {
            _battleController = BattleController.Instance;
            _uiController = GetComponent<BattleUIController>();
        }

        void Update()
        {
            if (!enableDebugging) return;

            HandleDebugInput();
        }

        private void HandleDebugInput()
        {
            // F1: ��ʾս��״̬
            if (Input.GetKeyDown(KeyCode.F1))
            {
                Debug.Log("=== ս��ϵͳ���� ===");

                if (_battleController != null)
                {
                    Debug.Log($"��һغ�: {_battleController.isPlayerTurn}");

                    if (_battleController.playerPet != null)
                    {
                        var pet = _battleController.playerPet;
                        Debug.Log($"��ҳ���: {pet.petName}");
                        Debug.Log($"  HP: {pet.CurrentHP}/{pet.MaxHP} (����: {pet.isDead})");
                        Debug.Log($"  �����ȼ�: ATK+{pet.attackLevel} MATK+{pet.magicAttackLevel} DEF+{pet.defenseLevel}");
                        Debug.Log($"  ��������: {pet.skills?.Count}");
                    }
                }
            }

            // F2: ����ս��
            if (Input.GetKeyDown(KeyCode.F2))
            {
                if (_battleController != null)
                {
                    Debug.Log("����ս��...");
                    _battleController.ResetBattle();
                }
            }

            // F3: ����UI
            if (Input.GetKeyDown(KeyCode.F3))
            {
                Debug.Log("=== UI���� ===");

                if (_uiController != null)
                {
                    Debug.Log($"���ܰ�ť����: {_uiController.skillButtons?.Length}");
                }
            }

            // F4: ǿ�Ƹ���UI
            if (Input.GetKeyDown(KeyCode.F4))
            {
                Debug.Log("ǿ�Ƹ���UI...");

                BattleEvents.TriggerSkillButtonsUpdateNeeded(_battleController?.playerPet);

                var pets = FindObjectsOfType<PetEntity>();
                foreach (var pet in pets)
                {
                    BattleEvents.TriggerPetUIUpdateNeeded(pet);
                }
            }

            // F5: ��ʾ������Ϣ
            if (Input.GetKeyDown(KeyCode.F5))
            {
                if (_battleController != null && _battleController.playerPet != null)
                {
                    var playerPet = _battleController.playerPet;
                    Debug.Log($"=== {playerPet.petName} ������Ϣ ===");

                    for (int i = 0; i < playerPet.skills.Count; i++)
                    {
                        var skill = playerPet.skills[i];
                        Debug.Log($"����{i}: {skill.skillName}");
                        Debug.Log($"  ����: {skill.category}, Ŀ��: {(skill.applyToTarget ? "Ŀ��" : "����")}");
                        Debug.Log($"  �Ƿ�Ϊ���Լ���: {skill.IsStatusSkill()}");
                        Debug.Log($"  PP: {skill.currentPP}/{skill.maxPP}");
                    }
                }
            }
        }
    }
}