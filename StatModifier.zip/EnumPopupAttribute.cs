using System;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace BattleSystem
{
    /// <summary>
    /// �Զ������ԣ�������Inspector����ʾö�ٵ������˵�
    /// </summary>
    [AttributeUsage(AttributeTargets.Field)]
    public class EnumPopupAttribute : PropertyAttribute
    {
        public Type enumType;

        public EnumPopupAttribute(Type enumType)
        {
            this.enumType = enumType;
        }
    }

#if UNITY_EDITOR
    /// <summary>
    /// �Զ���PropertyDrawer�����ڻ���EnumPopupAttribute��ǵ��ֶ�
    /// </summary>
    [CustomPropertyDrawer(typeof(EnumPopupAttribute))]
    public class EnumPopupDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            EnumPopupAttribute attr = attribute as EnumPopupAttribute;

            if (attr == null || !attr.enumType.IsEnum)
            {
                EditorGUI.PropertyField(position, property, label);
                return;
            }

            if (property.propertyType == SerializedPropertyType.String)
            {
                // ��ǰֵ
                string currentValue = property.stringValue;

                // ��ȡ����ö��ֵ����ʾ����
                Array enumValues = Enum.GetValues(attr.enumType);
                string[] displayNames = new string[enumValues.Length];
                string[] enumNames = new string[enumValues.Length];

                for (int i = 0; i < enumValues.Length; i++)
                {
                    var value = enumValues.GetValue(i);
                    var fieldInfo = attr.enumType.GetField(value.ToString());
                    var inspectorNameAttr = fieldInfo.GetCustomAttributes(typeof(InspectorNameAttribute), false);

                    if (inspectorNameAttr.Length > 0)
                    {
                        displayNames[i] = ((InspectorNameAttribute)inspectorNameAttr[0]).displayName;
                    }
                    else
                    {
                        displayNames[i] = value.ToString();
                    }
                    enumNames[i] = value.ToString();
                }

                // ���ҵ�ǰֵ������
                int currentIndex = Array.IndexOf(enumNames, currentValue);
                if (currentIndex < 0) currentIndex = 0;

                // ��ʾ�����˵�
                EditorGUI.BeginChangeCheck();
                int newIndex = EditorGUI.Popup(position, label.text, currentIndex, displayNames);

                if (EditorGUI.EndChangeCheck())
                {
                    property.stringValue = enumNames[newIndex];
                }
            }
            else if (property.propertyType == SerializedPropertyType.Enum)
            {
                // �����ö�����ͣ�ֱ�ӻ���
                EditorGUI.PropertyField(position, property, label);
            }
            else
            {
                EditorGUI.PropertyField(position, property, label);
            }
        }
    }
#endif
}