using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

namespace BattleSystem
{
    [RequireComponent(typeof(PetEntity))]
    public class PetUI : MonoBehaviour
    {
        [Header("UI����")]
        public Slider hpSlider;
        public Image hpFillImage;
        public TextMeshProUGUI hpText;
        public TextMeshProUGUI nameText;
        public TextMeshProUGUI levelText;

        [Header("״̬ͼ������")]
        public Transform statusIconContainer; // ����ק����UI�ﴴ��һ��Horizontal Layout Group��Ϊ����
        public GameObject statusIconPrefab;   // ����ק����� StatusIconUI Ԥ����

        [Header("״̬ͼ�꾫�飨��ѡ��")]
        public Sprite poisonIcon;
        public Sprite burnIcon;
        public Sprite paralyzeIcon;
        public Sprite sleepIcon;
        public Sprite freezeIcon;
        public Sprite leechSeedIcon;
        public Sprite confusionIcon;

        [Header("��ɫ����")]
        public Color hpHighColor = Color.green;
        public Color hpMediumColor = Color.yellow;
        public Color hpLowColor = Color.red;

        private PetEntity _petEntity;
        private Coroutine _hpAnimation;
        // ��һ���ֵ���׷�ٵ�ǰ��ʾ��ͼ�꣬����ɾ��
        private Dictionary<StatusCondition, StatusIconUI> _activeIcons = new Dictionary<StatusCondition, StatusIconUI>();

        void Awake()
        {
            _petEntity = GetComponent<PetEntity>();

            // �Զ�����UI��������δ���䣩
            if (hpSlider == null) hpSlider = GetComponentInChildren<Slider>();
            if (hpText == null) hpText = FindTextComponent("HP", "Ѫ");
            if (nameText == null) nameText = FindTextComponent("Name", "����");

            // ���û��ָ��״̬ͼ������������һ��
            if (statusIconContainer == null)
            {
                GameObject container = new GameObject("StatusIcons");
                container.transform.SetParent(transform, false);

                // ����������λ�ã��ڳ����Ϸ���
                RectTransform rect = container.AddComponent<RectTransform>();
                rect.anchoredPosition = new Vector2(0, 60f); // �ڳ����Ϸ�60����
                rect.sizeDelta = new Vector2(200, 40);

                // ���Ӳ������
                HorizontalLayoutGroup layout = container.AddComponent<HorizontalLayoutGroup>();
                layout.childAlignment = TextAnchor.MiddleCenter;
                layout.childControlWidth = false;
                layout.childControlHeight = false;
                layout.childForceExpandWidth = false;
                layout.childForceExpandHeight = false;
                layout.spacing = 5f;

                statusIconContainer = container.transform;
            }
        }

        void Start()
        {
            InitializeUI();
            SubscribeToEvents();
        }

        void OnDestroy()
        {
            UnsubscribeFromEvents();

            // ��������״̬ͼ��
            foreach (var icon in _activeIcons.Values)
            {
                if (icon != null && icon.gameObject != null)
                {
                    Destroy(icon.gameObject);
                }
            }
            _activeIcons.Clear();
        }

        private TextMeshProUGUI FindTextComponent(params string[] keywords)
        {
            var texts = GetComponentsInChildren<TextMeshProUGUI>();
            foreach (var text in texts)
            {
                foreach (var keyword in keywords)
                {
                    if (text.name.Contains(keyword))
                    {
                        return text;
                    }
                }
            }
            return null;
        }

        private void SubscribeToEvents()
        {
            BattleEvents.OnPetHPChanged += OnPetHPChanged;
            BattleEvents.OnPetUIUpdateNeeded += OnPetUIUpdateNeeded;
            BattleEvents.OnStatusEffectApplied += OnStatusEffectApplied;
            BattleEvents.OnStatusEffectRemoved += OnStatusEffectRemoved;
            BattleEvents.OnStatusEffectUpdated += OnStatusEffectUpdated;
        }

        private void UnsubscribeFromEvents()
        {
            BattleEvents.OnPetHPChanged -= OnPetHPChanged;
            BattleEvents.OnPetUIUpdateNeeded -= OnPetUIUpdateNeeded;
            BattleEvents.OnStatusEffectApplied -= OnStatusEffectApplied;
            BattleEvents.OnStatusEffectRemoved -= OnStatusEffectRemoved;
            BattleEvents.OnStatusEffectUpdated -= OnStatusEffectUpdated;
        }

        private void InitializeUI()
        {
            if (nameText != null && _petEntity != null)
            {
                nameText.text = _petEntity.petName;
            }

            if (hpSlider != null)
            {
                hpSlider.maxValue = _petEntity.MaxHP;
                hpSlider.value = _petEntity.CurrentHP;
            }

            UpdateHPDisplay();
        }

        private void OnPetHPChanged(PetEntity pet, int currentHP, int maxHP)
        {
            if (pet != _petEntity) return;
            UpdateHPDisplay();
        }

        private void OnPetUIUpdateNeeded(PetEntity pet)
        {
            if (pet != _petEntity) return;
            UpdateHPDisplay();
        }

        // ����״̬Ч��Ӧ��
        private void OnStatusEffectApplied(PetEntity pet, StatusEffect effect)
        {
            if (pet != _petEntity || effect == null)
            {
                Debug.Log($"���ǵ�ǰ�����effectΪ��: pet={pet?.petName}, _petEntity={_petEntity?.petName}");
                return;
            }

            Debug.Log($"OnStatusEffectApplied: {pet.petName} ���״̬ {effect.condition}");

            // ����Ѿ������ͼ���ˣ��͸�����
            if (_activeIcons.ContainsKey(effect.condition))
            {
                _activeIcons[effect.condition].UpdateStatus(effect.remainingTurns, 1);
                Debug.Log($"��������ͼ��: {effect.condition}");
            }
            else
            {
                // ʵ������ͼ��
                if (statusIconPrefab != null && statusIconContainer != null)
                {
                    GameObject iconObj = Instantiate(statusIconPrefab, statusIconContainer);
                    StatusIconUI iconUI = iconObj.GetComponent<StatusIconUI>();

                    if (iconUI == null)
                    {
                        Debug.LogError("״̬ͼ��Ԥ����ȱ�� StatusIconUI �����");
                        Destroy(iconObj);
                        return;
                    }

                    // ��ʼ��ͼ��
                    iconUI.Initialize(effect.condition, effect.remainingTurns, 1, pet);

                    // ����ͼ��ͼƬ
                    SetStatusIconSprite(iconUI, effect.condition);

                    _activeIcons.Add(effect.condition, iconUI);
                    Debug.Log($"������ͼ��: {effect.condition}, ��ǰͼ����: {_activeIcons.Count}");
                }
                else
                {
                    Debug.LogWarning($"�޷�����״̬ͼ��: prefab={statusIconPrefab}, container={statusIconContainer}");
                }
            }
        }

        // ����״̬Ч���Ƴ�
        private void OnStatusEffectRemoved(PetEntity pet, StatusCondition condition)
        {
            if (pet != _petEntity)
            {
                Debug.Log($"���ǵ�ǰ����: pet={pet?.petName}, _petEntity={_petEntity?.petName}");
                return;
            }

            Debug.Log($"OnStatusEffectRemoved: {pet.petName} �Ƴ�״̬ {condition}");

            if (_activeIcons.ContainsKey(condition))
            {
                // ����ͼ�����
                if (_activeIcons[condition] != null)
                {
                    Destroy(_activeIcons[condition].gameObject);
                }
                _activeIcons.Remove(condition);
                Debug.Log($"�Ƴ�ͼ��: {condition}, ʣ��ͼ����: {_activeIcons.Count}");
            }
        }

        // ����״̬Ч������
        private void OnStatusEffectUpdated(PetEntity pet, StatusEffect effect)
        {
            if (pet != _petEntity) return;

            if (_activeIcons.ContainsKey(effect.condition))
            {
                _activeIcons[effect.condition].UpdateStatus(effect.remainingTurns, 1);
                Debug.Log($"����ͼ��: {effect.condition}, ʣ��غ�: {effect.remainingTurns}");
            }
        }

        // ��������������״̬��������ͼ�꣨�޸��� - ����������
        private void SetStatusIconSprite(StatusIconUI iconUI, StatusCondition condition)
        {
            if (iconUI == null || iconUI.statusIcon == null)
            {
                Debug.LogWarning("StatusIconUI �� statusIcon Ϊ��");
                return;
            }

            // ��龫���Ƿ���Inspector���ֶ�����
            Sprite iconSprite = null;

            // ʹ��switch��䣬��ֻ��������Ŀ��ʵ�ʴ��ڵ�ö��ֵ
            switch (condition)
            {
                case StatusCondition.Poison:
                    iconSprite = poisonIcon;
                    break;
                case StatusCondition.Burn:
                    iconSprite = burnIcon;
                    break;
                case StatusCondition.Paralyze:
                    iconSprite = paralyzeIcon;
                    break;
                    // ֻ��������Ŀ��ʵ�ʴ��ڵ�ö��ֵ
                    // �����ȷ���������������
            }

            // ���Inspector��û�����ã����Դ�Resources����
            if (iconSprite == null)
            {
                string spriteName = GetStatusIconName(condition);
                if (!string.IsNullOrEmpty(spriteName))
                {
                    iconSprite = Resources.Load<Sprite>($"StatusIcons/{spriteName}");
                }
            }

            // ����ͼ��
            if (iconSprite != null)
            {
                iconUI.statusIcon.sprite = iconSprite;
            }
            else
            {
                Debug.LogWarning($"δ�ҵ�״̬���� {condition} ��ͼ��");
                // ����һ��Ĭ��ͼ��
                iconUI.statusIcon.color = Color.red;
            }
        }

        // ��������������״̬������ȡͼ������
        private string GetStatusIconName(StatusCondition condition)
        {
            return condition.ToString();
        }

        private void UpdateHPDisplay()
        {
            // ����HP�ı�
            if (hpText != null)
            {
                hpText.text = $"{_petEntity.CurrentHP}/{_petEntity.MaxHP}";
            }

            // ����HP����ɫ
            UpdateHPBarColor();

            // ��������HP��
            if (hpSlider != null)
            {
                if (_hpAnimation != null)
                {
                    StopCoroutine(_hpAnimation);
                }
                _hpAnimation = StartCoroutine(AnimateHPBar(_petEntity.CurrentHP));
            }
        }

        private System.Collections.IEnumerator AnimateHPBar(float targetValue)
        {
            if (hpSlider == null) yield break;

            float startValue = hpSlider.value;
            float elapsed = 0f;
            float duration = BattleConstants.HP_ANIMATION_DURATION;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);
                hpSlider.value = Mathf.Lerp(startValue, targetValue, t);
                yield return null;
            }

            hpSlider.value = targetValue;
            _hpAnimation = null;
        }

        private void UpdateHPBarColor()
        {
            if (hpFillImage == null || _petEntity.MaxHP <= 0) return;

            float hpPercent = (float)_petEntity.CurrentHP / _petEntity.MaxHP;

            if (hpPercent <= 0.3f)
                hpFillImage.color = hpLowColor;
            else if (hpPercent <= 0.6f)
                hpFillImage.color = hpMediumColor;
            else
                hpFillImage.color = hpHighColor;
        }

        void OnValidate()
        {
#if UNITY_EDITOR
            if (!Application.isPlaying && hpSlider != null)
            {
                var pet = GetComponent<PetEntity>();
                if (pet != null)
                {
                    hpSlider.maxValue = pet.MaxHP;
                    hpSlider.value = pet.CurrentHP;
                    UpdateHPBarColor();
                }
            }
#endif
        }
    }
}