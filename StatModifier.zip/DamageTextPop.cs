using TMPro;
using UnityEngine;

namespace BattleSystem
{
    public class DamageTextPop : MonoBehaviour
    {
        public enum DamageType
        {
            Normal,
            Critical,
            SuperEffective,
            Weak,
            Heal,
            Status
        }

        [Header("��������")]
        public float moveSpeed = 50f;
        public float fadeSpeed = 0.5f;
        public float lifeTime = 2.0f;

        [Header("Ч������")]
        public float normalScale = 1.5f;
        public Color normalColor = Color.red;
        public float critScale = 2.5f;
        public Color critColor = new Color(1f, 0.2f, 0f);
        public float superScale = 2.2f;
        public Color superColor = new Color(1f, 0.5f, 0f);
        public Color weakColor = Color.gray;
        public float weakScale = 0.8f;
        public Color healColor = Color.green;  // ȷ����������ɫ
        public Color statusColor = Color.cyan;

        [Header("������Ч")]
        public AnimationCurve healScaleCurve = AnimationCurve.EaseInOut(0, 1, 1, 1.5f);
        public float healPulseSpeed = 3f;

        private TextMeshProUGUI _textMesh;
        private Vector3 _originalScale;
        private float _timer = 0f;
        private DamageType _currentType;
        private Vector3 _originalPosition;

        void Awake()
        {
            _textMesh = GetComponent<TextMeshProUGUI>();
            if (_textMesh == null)
            {
                Debug.LogError("DamageTextPop: ȱ��TextMeshProUGUI���!");
                return;
            }

            _originalScale = transform.localScale;
            _originalPosition = transform.position;

            // ȷ��������ɫ����ɫ
            if (healColor == Color.green)
            {
                Debug.Log("DamageTextPop: ������ɫ������Ϊ��ɫ");
            }
            else
            {
                Debug.LogWarning($"DamageTextPop: ������ɫ���Ǵ���ɫ����ǰֵ: {healColor}");
                // ǿ������Ϊ��ɫ
                healColor = Color.green;
            }
        }

        public void ShowDamage(int amount, DamageType type = DamageType.Normal)
        {
            _currentType = type;
            _timer = 0f;

            if (_textMesh == null)
            {
                Debug.LogError("DamageTextPop: _textMeshΪ��!");
                return;
            }

            // �����ʼλ�����ڶ���Ч��
            _originalPosition = transform.position;

            string prefix = GetPrefixForType(type);

            if (type == DamageType.Heal)
            {
                // ������ʾΪ +XX ��ɫ
                _textMesh.text = $"+{amount}";
                _textMesh.color = healColor;
                Debug.Log($"DamageTextPop: ��ʾ�������� +{amount}, ��ɫ: {healColor}");
            }
            else if (amount <= 0)
            {
                _textMesh.text = prefix;
                _textMesh.color = GetColorForType(type);
            }
            else
            {
                _textMesh.text = $"{prefix} {amount}";
                _textMesh.color = GetColorForType(type);
            }

            // ��������
            transform.localScale = _originalScale * GetScaleForType(type);

            // ���������С
            if (type == DamageType.Critical)
            {
                _textMesh.fontSize = 48f;
            }
            else if (type == DamageType.Heal)
            {
                _textMesh.fontSize = 40f; // ���������Դ�
            }
            else
            {
                _textMesh.fontSize = 36f;
            }

            // ����ʱ���Ӷ���Ч��
            if (type == DamageType.Critical)
            {
                StartCoroutine(CriticalShake());
            }
            // ����ʱ��������Ч��
            else if (type == DamageType.Heal)
            {
                StartCoroutine(HealPulseEffect());
                Debug.Log("DamageTextPop: ������������Ч��");
            }

            // �Զ�����
            Destroy(gameObject, lifeTime);

            Debug.Log($"DamageTextPop: ��ʾ��������: {type}, ��ֵ: {amount}, ��ɫ: {_textMesh.color}");
        }

        void Update()
        {
            if (_textMesh == null) return;

            _timer += Time.deltaTime;

            // �����ƶ�
            transform.position += new Vector3(0, moveSpeed * Time.deltaTime, 0);

            // ����Ч��
            if (_timer > lifeTime - 0.5f)
            {
                Color color = _textMesh.color;
                float fadeProgress = (_timer - (lifeTime - 0.5f)) / 0.5f;
                color.a = Mathf.Lerp(1f, 0f, fadeProgress);
                _textMesh.color = color;
            }
        }

        private System.Collections.IEnumerator CriticalShake()
        {
            float duration = 0.3f;
            float elapsed = 0f;
            Vector3 originalPos = _originalPosition;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float shakeAmount = Mathf.Lerp(10f, 0f, elapsed / duration);
                transform.position = originalPos + new Vector3(
                    Random.Range(-shakeAmount, shakeAmount) * Time.deltaTime * 10f,
                    Random.Range(-shakeAmount, shakeAmount) * Time.deltaTime * 10f,
                    0
                );
                yield return null;
            }

            transform.position = originalPos;
        }

        private System.Collections.IEnumerator HealPulseEffect()
        {
            float duration = 0.5f;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float scaleMultiplier = healScaleCurve.Evaluate(t);
                transform.localScale = _originalScale * scaleMultiplier;

                // ��΢����ɫ��˸
                if (_textMesh != null)
                {
                    float colorPulse = Mathf.Sin(elapsed * healPulseSpeed) * 0.2f + 0.8f;
                    Color color = healColor;
                    color.r = Mathf.Clamp(color.r * colorPulse, 0.5f, 1f);
                    color.g = Mathf.Clamp(color.g * colorPulse, 0.8f, 1f);
                    _textMesh.color = color;
                }

                yield return null;
            }

            // �ָ���ԭʼ��С
            transform.localScale = _originalScale;
        }

        private string GetPrefixForType(DamageType type)
        {
            switch (type)
            {
                case DamageType.Critical:
                    return "����!";
                case DamageType.SuperEffective:
                    return "Ч������!";
                case DamageType.Weak:
                    return "Ч��һ��";
                case DamageType.Heal:
                    return "+";
                case DamageType.Status:
                    return "״̬";
                case DamageType.Normal:
                default:
                    return "-";
            }
        }

        private Color GetColorForType(DamageType type)
        {
            switch (type)
            {
                case DamageType.Critical:
                    return critColor;
                case DamageType.SuperEffective:
                    return superColor;
                case DamageType.Weak:
                    return weakColor;
                case DamageType.Heal:
                    return healColor; // ȷ�����ص�����ɫ
                case DamageType.Status:
                    return statusColor;
                case DamageType.Normal:
                default:
                    return normalColor;
            }
        }

        private float GetScaleForType(DamageType type)
        {
            switch (type)
            {
                case DamageType.Critical:
                    return critScale;
                case DamageType.SuperEffective:
                    return superScale;
                case DamageType.Weak:
                    return weakScale;
                case DamageType.Heal:
                    return 1.0f;
                case DamageType.Status:
                    return 1.0f;
                case DamageType.Normal:
                default:
                    return normalScale;
            }
        }

        // �����ɫ���ã��༭����ʹ�ã�
        void OnValidate()
        {
#if UNITY_EDITOR
            // �ڱ༭����ȷ��������ɫ����ɫ
            if (healColor != Color.green)
            {
                Debug.LogWarning("DamageTextPop: ������ɫ������ɫ�����Զ�����");
                healColor = Color.green;
            }
#endif
        }
    }
}