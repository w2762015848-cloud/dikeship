using TMPro;
using UnityEngine;

namespace BattleSystem
{
    public class StatusTooltip : MonoBehaviour
    {
        [Header("UI���")]
        public TextMeshProUGUI tooltipText;
        public RectTransform tooltipRect;
        public CanvasGroup canvasGroup;

        [Header("��ʾ����")]
        public float fadeInSpeed = 10f;
        public float fadeOutSpeed = 5f;
        public Vector2 offset = new Vector2(0, 60); // Ĭ������ƫ��

        private bool _isShowing = false;
        private string _currentText = "";

        void Awake()
        {
            // �Զ���ȡ���
            if (tooltipText == null)
                tooltipText = GetComponentInChildren<TextMeshProUGUI>();

            if (tooltipRect == null)
                tooltipRect = GetComponent<RectTransform>();

            if (canvasGroup == null)
            {
                canvasGroup = GetComponent<CanvasGroup>();
                if (canvasGroup == null)
                {
                    canvasGroup = gameObject.AddComponent<CanvasGroup>();
                }
            }

            // ��ʼ����
            if (canvasGroup != null)
            {
                canvasGroup.alpha = 0f;
                canvasGroup.blocksRaycasts = false;
                canvasGroup.interactable = false;
            }
        }

        void Update()
        {
            // ���뵭��Ч��
            if (canvasGroup != null)
            {
                float targetAlpha = _isShowing ? 1f : 0f;
                float currentAlpha = canvasGroup.alpha;
                float speed = _isShowing ? fadeInSpeed : fadeOutSpeed;

                if (Mathf.Abs(currentAlpha - targetAlpha) > 0.01f)
                {
                    canvasGroup.alpha = Mathf.Lerp(currentAlpha, targetAlpha, Time.deltaTime * speed);
                }
                else
                {
                    canvasGroup.alpha = targetAlpha;
                }

                // ��ȫ���غ�����
                if (!_isShowing && canvasGroup.alpha <= 0.01f)
                {
                    Destroy(gameObject);
                }
            }
        }

        public void SetText(string text)
        {
            _currentText = text;
            if (tooltipText != null)
            {
                tooltipText.text = text;
            }
        }

        public void SetPosition(Vector2 anchoredPosition)
        {
            if (tooltipRect != null)
            {
                tooltipRect.anchoredPosition = anchoredPosition;
                AdjustPositionToStayOnScreen();
            }
        }

        private void AdjustPositionToStayOnScreen()
        {
            if (tooltipRect == null) return;

            // ��ȡ��Canvas
            Canvas canvas = GetComponentInParent<Canvas>();
            if (canvas == null) return;

            RectTransform canvasRect = canvas.GetComponent<RectTransform>();
            if (canvasRect == null) return;

            Vector2 canvasSize = canvasRect.rect.size;
            Vector2 tooltipSize = tooltipRect.rect.size;
            Vector2 anchoredPos = tooltipRect.anchoredPosition;

            // ����Ƿ񳬳��Ҳ�߽�
            float rightEdge = anchoredPos.x + tooltipSize.x / 2;
            if (rightEdge > canvasSize.x / 2)
            {
                anchoredPos.x = canvasSize.x / 2 - tooltipSize.x / 2 - 10;
            }

            // ����Ƿ񳬳����߽�
            float leftEdge = anchoredPos.x - tooltipSize.x / 2;
            if (leftEdge < -canvasSize.x / 2)
            {
                anchoredPos.x = -canvasSize.x / 2 + tooltipSize.x / 2 + 10;
            }

            // ����Ƿ񳬳��ϲ�߽�
            float topEdge = anchoredPos.y + tooltipSize.y / 2;
            if (topEdge > canvasSize.y / 2)
            {
                anchoredPos.y = canvasSize.y / 2 - tooltipSize.y / 2 - 10;
            }

            tooltipRect.anchoredPosition = anchoredPos;
        }

        public void Show()
        {
            _isShowing = true;
            if (canvasGroup != null)
            {
                canvasGroup.blocksRaycasts = false; // ������ʾ��Ӧ���赲����
            }
        }

        public void Hide()
        {
            _isShowing = false;
        }

        public void SetActive(bool active)
        {
            gameObject.SetActive(active);
            if (active)
            {
                Show();
            }
            else
            {
                Hide();
            }
        }
    }
}