using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace BattleSystem
{
    public class SkillExecutor : MonoBehaviour
    {
        [Header("����")]
        public BattleController battleController;

        [Header("����")]
        public float statusEffectDelay = 0.5f;
        public float skillExecutionDelay = 0.3f;

        // ���������ƺ��˺�������ʾ����ֶ�
        [Header("������ʾ����")]
        public GameObject damageTextPrefab;      // �˺�����Ԥ����
        public RectTransform damageCanvas;       // �˺����ֻ���
        public float damageNumberYOffset = 50f;  // ���ִ�ֱƫ��

        [Header("������Ч")]
        public GameObject healEffectPrefab;      // ������ЧԤ���壨��ѡ��
        public Color healTextColor = Color.green; // ����������ɫ

        void Start()
        {
            // �Զ���������
            if (damageCanvas == null)
            {
                GameObject canvasObj = GameObject.Find("Damage_Canvas");
                if (canvasObj != null)
                {
                    damageCanvas = canvasObj.GetComponent<RectTransform>();
                    Debug.Log($"�Զ��ҵ� Damage_Canvas: {damageCanvas != null}");
                }
            }

            if (damageTextPrefab == null)
            {
                // ���Դ� Resources ����Ĭ��Ԥ����
                damageTextPrefab = Resources.Load<GameObject>("DamageTextPrefab");
                if (damageTextPrefab != null)
                {
                    Debug.Log("�� Resources ���� DamageTextPrefab");
                }
            }
        }

        // ִ�м���
        public void ExecuteSkill(PetEntity attacker, PetEntity target, SkillData skill)
        {
            if (skill == null || attacker == null)
            {
                Debug.LogError("����ִ����: ����Ϊ��");
                return;
            }

            StartCoroutine(ExecuteSkillCoroutine(attacker, target, skill));
        }

        // ִ�м���Э��
        private IEnumerator ExecuteSkillCoroutine(PetEntity attacker, PetEntity target, SkillData skill)
        {
            Debug.Log($"{attacker.petName} ʹ�� {skill.skillName}");

            // �����ӳ�����ҿ�������ѡ��
            yield return new WaitForSeconds(skillExecutionDelay);

            // ��鼼������
            if (skill.IsStatusSkill())
            {
                ExecuteStatusSkill(attacker, target, skill);
            }
            else
            {
                ExecuteDamageSkill(attacker, target, skill);
            }
        }

        // ִ���˺�����
        private void ExecuteDamageSkill(PetEntity attacker, PetEntity target, SkillData skill)
        {
            // �������
            if (!DamageCalculator.CheckHit(skill.accuracy, attacker))
            {
                ShowDamagePopup(target, 0, 1.0f, "Miss", DamageTextPop.DamageType.Normal);
                StartCoroutine(EndTurnAfterDelay(attacker));
                return;
            }

            // ����Ƿ�ṥ���Լ�������״̬��
            if (StatusEffectManager.Instance != null &&
                StatusEffectManager.Instance.ShouldAttackSelf(attacker))
            {
                // �����Լ�
                DamageResult selfDamageResult = DamageCalculator.CalculateDamage(attacker, attacker, skill);
                attacker.TakeDamage(selfDamageResult.damage);

                ShowDamagePopup(attacker, selfDamageResult.damage, selfDamageResult.elementMultiplier,
                               "���ҹ����Լ�!", GetDamageType(selfDamageResult));

                // �����غ�
                StartCoroutine(EndTurnAfterDelay(attacker));
                return;
            }

            // �����˺�
            DamageResult damageResult = DamageCalculator.CalculateDamage(attacker, target, skill);

            // Ӧ���˺�
            target.TakeDamage(damageResult.damage);

            // ��ʾ�˺�����
            ShowDamagePopup(target, damageResult.damage, damageResult.elementMultiplier,
                           damageResult.GetDisplayText(), GetDamageType(damageResult));

            // ��������Ч��
            ProcessSkillEffects(attacker, target, skill, damageResult.damage);

            // Ӧ��״̬Ч��
            if (skill.applyStatus != StatusCondition.None && skill.statusChance > 0)
            {
                // ���״̬ʩ�Ӹ���
                if (Random.Range(0, 100) < skill.statusChance)
                {
                    ApplyStatusEffect(attacker, target, skill.applyStatus, skill.statusDuration, skill.statusDamageRate);
                }
            }

            // ���״̬Ч��
            if (skill.canClearStatus)
            {
                ClearStatusEffects(attacker, target, skill);
            }

            // �����غ�
            StartCoroutine(EndTurnAfterDelay(attacker));
        }

        // ִ�����Լ���
        private void ExecuteStatusSkill(PetEntity attacker, PetEntity target, SkillData skill)
        {
            // ������У����Լ���Ҳ��Ҫ�����ж���
            if (!DamageCalculator.CheckHit(skill.accuracy, attacker))
            {
                ShowStatusPopup(target, "Miss");
                StartCoroutine(EndTurnAfterDelay(attacker));
                return;
            }

            // ȷ��Ŀ��
            PetEntity actualTarget = skill.applyToTarget ? target : attacker;

            // Ӧ�����Ա仯
            if (skill.HasStatModifiers())
            {
                foreach (var modifier in skill.statModifiers)
                {
                    actualTarget.ModifyStat(modifier.statType, modifier.value);
                    Debug.Log($"{actualTarget.petName} {modifier.ToString()}");
                }
            }

            // Ӧ��״̬Ч��
            if (skill.applyStatus != StatusCondition.None && skill.statusChance > 0)
            {
                // ���״̬ʩ�Ӹ���
                if (Random.Range(0, 100) < skill.statusChance)
                {
                    ApplyStatusEffect(attacker, actualTarget, skill.applyStatus, skill.statusDuration, skill.statusDamageRate);
                }
            }

            // ���״̬Ч��
            if (skill.canClearStatus)
            {
                ClearStatusEffects(attacker, actualTarget, skill);
            }

            // ��ʾ״̬�仯
            ShowStatusPopup(actualTarget, skill);

            // �����غ�
            StartCoroutine(EndTurnAfterDelay(attacker));
        }

        // Ӧ��״̬Ч��
        private void ApplyStatusEffect(PetEntity attacker, PetEntity target,
                                      StatusCondition condition, int customDuration, float damageRate)
        {
            var statusManager = StatusEffectManager.Instance;
            if (statusManager == null) return;

            // ȷ������ʱ�䣺����ʹ�ü����Զ���ģ�����ʹ��Ĭ�ϵ�
            int duration = customDuration > 0 ? customDuration : StatusEffectConfig.GetDuration(condition);

            StatusEffect effect = new StatusEffect
            {
                condition = condition,
                remainingTurns = duration,
                sourcePetId = attacker?.GetInstanceID().ToString(),
                damageRate = damageRate
            };

            bool success = statusManager.AddStatusEffect(target, effect);

            if (success)
            {
                Debug.Log($"{target.petName} ��ʩ���� {condition} ״̬������ {duration} �غ�");
                ShowStatusPopup(target, $"{StatusEffectConfig.GetDisplayName(condition)}!");
            }
        }

        // ���״̬Ч��
        private void ClearStatusEffects(PetEntity attacker, PetEntity target, SkillData skill)
        {
            var statusManager = StatusEffectManager.Instance;
            if (statusManager == null) return;

            if (skill.clearAllStatus)
            {
                // �������״̬
                statusManager.ClearAllStatusEffects(target);
                Debug.Log($"{target.petName} ������״̬�����");
                ShowStatusClearPopup(target);
            }
            else if (skill.clearStatusType != StatusCondition.None)
            {
                // ����ض�����״̬
                statusManager.ClearStatusEffectsOfType(target, skill.clearStatusType);
                Debug.Log($"{target.petName} �� {skill.clearStatusType} ״̬�����");
                ShowStatusClearPopup(target, skill.clearStatusType);
            }
        }

        // ������������Ч��
        private void ProcessSkillEffects(PetEntity attacker, PetEntity target, SkillData skill, int damage)
        {
            switch (skill.effectType)
            {
                case SkillEffectType.Drain: // ��Ѫ
                    int healAmount = Mathf.RoundToInt(damage * skill.effectValue);
                    if (healAmount > 0)
                    {
                        attacker.Heal(healAmount);
                        ShowHealPopup(attacker, healAmount); // ��ʾ��������
                    }
                    break;

                case SkillEffectType.PercentageDamage: // �ٷֱ��˺�
                    int percentDamage = Mathf.RoundToInt(target.CurrentHP * skill.effectValue);
                    target.TakeDamage(percentDamage);
                    ShowDamagePopup(target, percentDamage, 1.0f, "%DMG", DamageTextPop.DamageType.Normal);
                    break;

                case SkillEffectType.Heal: // ����
                    int heal = Mathf.RoundToInt(skill.power * skill.effectValue);
                    if (heal > 0)
                    {
                        target.Heal(heal);
                        ShowHealPopup(target, heal); // ��ʾ��������
                    }
                    break;
            }
        }

        // ��ȡ�˺�����
        private DamageTextPop.DamageType GetDamageType(DamageResult result)
        {
            if (result.isCritical) return DamageTextPop.DamageType.Critical;

            switch (result.elementLabel)
            {
                case "SUPER": return DamageTextPop.DamageType.SuperEffective;
                case "WEAK":
                case "NVE": return DamageTextPop.DamageType.Weak;
                default: return DamageTextPop.DamageType.Normal;
            }
        }

        // ��ʾ�˺�����
        private void ShowDamagePopup(PetEntity target, int damage, float multiplier, string prefix, DamageTextPop.DamageType type)
        {
            if (damageTextPrefab == null || damageCanvas == null)
            {
                Debug.LogWarning("�˺�������ʾ: ȱ��Ԥ����򻭲�����");
                BattleEvents.TriggerDamageDealt(null, target, null, damage);
                return;
            }

            try
            {
                // �����˺�����
                GameObject damageTextObj = Instantiate(damageTextPrefab, damageCanvas);
                DamageTextPop damageText = damageTextObj.GetComponent<DamageTextPop>();

                if (damageText != null)
                {
                    // ��ȡĿ��λ��
                    Vector3 targetPosition = Vector3.zero;

                    // ���ȳ��Ի�ȡUIλ��
                    RectTransform targetRect = target.GetComponent<RectTransform>();
                    if (targetRect != null)
                    {
                        targetPosition = targetRect.position;
                    }
                    else
                    {
                        // ���û��RectTransform��ʹ������λ�ò�ת��Ϊ��Ļ����
                        targetPosition = Camera.main.WorldToScreenPoint(target.transform.position);
                    }

                    // �������ƫ��
                    Vector3 offset = new Vector3(
                        Random.Range(-30f, 30f),
                        damageNumberYOffset + Random.Range(-10f, 10f),
                        0
                    );

                    damageText.transform.position = targetPosition + offset;

                    // ��ʾ�˺�����
                    damageText.ShowDamage(damage, type);
                    Debug.Log($"��ʾ�˺�����: {target.petName} -{damage}");
                }

                BattleEvents.TriggerDamageDealt(null, target, null, damage);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"��ʾ�˺�����ʱ����: {e.Message}");
            }

            // ���������̨
            string multiplierText = multiplier != 1.0f ? $" (x{multiplier})" : "";
            Debug.Log($"{target.petName} �ܵ� {damage} ���˺� {multiplierText} ({prefix})");
        }

        // ��ʾ�������֣��޸��汾��
        private void ShowHealPopup(PetEntity target, int healAmount)
        {
            if (target == null)
            {
                Debug.LogWarning("ShowHealPopup: Ŀ��Ϊ��");
                return;
            }

            if (damageTextPrefab == null)
            {
                Debug.LogWarning("ShowHealPopup: �˺�����Ԥ����Ϊ��");
                // ���Դ�Resources����
                damageTextPrefab = Resources.Load<GameObject>("DamageTextPrefab");
                if (damageTextPrefab == null)
                {
                    Debug.LogError("ShowHealPopup: �޷������˺�����Ԥ����");
                    return;
                }
            }

            if (damageCanvas == null)
            {
                // ���Բ���Damage Canvas
                GameObject canvasObj = GameObject.Find("Damage_Canvas");
                if (canvasObj != null)
                {
                    damageCanvas = canvasObj.GetComponent<RectTransform>();
                }

                if (damageCanvas == null)
                {
                    // �����µ�Canvas
                    canvasObj = new GameObject("Damage_Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
                    damageCanvas = canvasObj.GetComponent<RectTransform>();
                    Canvas canvas = canvasObj.GetComponent<Canvas>();
                    canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    canvas.sortingOrder = 100; // ȷ�������ϲ�
                }
            }

            try
            {
                // ������������
                GameObject healTextObj = Instantiate(damageTextPrefab, damageCanvas);
                DamageTextPop healText = healTextObj.GetComponent<DamageTextPop>();

                if (healText != null)
                {
                    // ��ȡĿ��λ��
                    Vector3 targetPosition = Vector3.zero;

                    // ���ȳ��Ի�ȡUIλ��
                    RectTransform targetRect = target.GetComponent<RectTransform>();
                    if (targetRect != null)
                    {
                        targetPosition = targetRect.position;
                    }
                    else
                    {
                        // ���û��RectTransform��ʹ������λ�ò�ת��Ϊ��Ļ����
                        targetPosition = Camera.main.WorldToScreenPoint(target.transform.position);
                    }

                    // �������ƫ��
                    Vector3 offset = new Vector3(
                        Random.Range(-30f, 30f),
                        damageNumberYOffset + Random.Range(20f, 40f), // �������ֱ��˺����ָ���
                        0
                    );

                    healText.transform.position = targetPosition + offset;

                    // ��ʾ�������� - ȷ��ʹ��Heal����
                    healText.ShowDamage(healAmount, DamageTextPop.DamageType.Heal);
                    Debug.Log($"��ʾ��������: {target.petName} +{healAmount}");
                }
                else
                {
                    Debug.LogWarning("����������ʾ: DamageTextPop���ȱʧ");
                }

                // ��ѡ������������Ч
                if (healEffectPrefab != null)
                {
                    GameObject healEffect = Instantiate(healEffectPrefab, target.transform);
                    healEffect.transform.localPosition = Vector3.zero;
                    Destroy(healEffect, 1f);
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"��ʾ��������ʱ����: {e.Message}\n{e.StackTrace}");
            }

            // ���������¼�
            BattleEvents.TriggerHealReceived(target, healAmount);
        }

        // ��ʾ״̬�仯
        private void ShowStatusPopup(PetEntity target, SkillData skill)
        {
            string statusText = "״̬�仯";
            if (skill.HasStatModifiers())
            {
                statusText = "���Ա仯: ";
                foreach (var modifier in skill.statModifiers)
                {
                    statusText += modifier.ToString() + " ";
                }
            }

            Debug.Log($"{target.petName} {statusText}");
        }

        // ��ʾ״̬ʩ����Ч
        private void ShowStatusPopup(PetEntity target, string statusText)
        {
            Debug.Log($"{target.petName} {statusText}");
        }

        private void ShowStatusClearPopup(PetEntity target, StatusCondition? condition = null)
        {
            string text = condition.HasValue ?
                $"{StatusEffectConfig.GetDisplayName(condition.Value)} ���!" :
                "״̬���!";
            Debug.Log($"{target.petName} {text}");
        }

        // �����غ��ӳ�
        private IEnumerator EndTurnAfterDelay(PetEntity attacker)
        {
            yield return new WaitForSeconds(statusEffectDelay);

            if (battleController != null)
            {
                battleController.EndTurn(attacker);
            }
        }
    }
}